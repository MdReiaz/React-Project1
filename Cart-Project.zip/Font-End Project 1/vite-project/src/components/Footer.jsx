import React from "react";

const Footer = () => {
    return (
        <div className="bg-dark container-fluid footer-base m-0 p-3">
          <div className="row">
            <div className="col-12 mt-2 text-center text-white">
                    <p>Copy Right by REIAZ</p>
            </div>
          </div>
        </div>
    );
};

export default Footer;